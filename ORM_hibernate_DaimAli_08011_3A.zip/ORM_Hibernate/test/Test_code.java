package lab11;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 *
 */
public class Test_code {
    
    public Test_code() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }
    
    
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        ORM_implement.main(args);
        // TODO review the generated test code and remove the default call to fail.
     
    }
    

    /**
     * Test of businessLogicAdd method, of class ORM_implement.
     */
    @Test
    public void testBusinessLogicAdd() {
        System.out.println("businessLogicAdd");
        int expected_output = 2;
        int output= ORM_implement.businessLogicAdd();
        assertEquals(expected_output, output);
        
        
    }

    /**
     * Test of businessLogicRetrive method, of class ORM_implement.
     */
    @Test
    public void testBusinessLogicRetrive() {
        System.out.println("businessLogicRetrive");
        int expected_output = 1;
        int output= ORM_implement.businessLogicRetrive();
        assertEquals(expected_output, output);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of main method, of class ORM_implement.
     */
    
    
}
