package lab10;

import attendance.ui.AttendanceSystem;
import pk.edu.nust.seecs.gradebook.dao.*;
import pk.edu.nust.seecs.gradebook.entity.*;
import pk.edu.nust.seecs.gradebook.util.*;
import attendance.util.HibernateUtil;
import attendance.entity.*;
import java.util.Date;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

/**
 *
 * 
 */
public class ORM_implement {

    /**
     * @param args the command line arguments
     */
    
   //adding teacher and students
 public static int good = 0;
    
    //adds the data using both the given appplication using business logic add class
  
    
    public static int businessLogicRetrive(){
        
      AttendanceSystem attend_system = new AttendanceSystem();
       
        pk.edu.nust.seecs.gradebook.entity.Course course_latest,course_latest_2;
        
       course_latest = new pk.edu.nust.seecs.gradebook.entity.Course();
       
       pk.edu.nust.seecs.gradebook.entity.Teacher Instructor1,Instructor2;
        
       Instructor1 = new  pk.edu.nust.seecs.gradebook.entity.Teacher();
       
       
       String CourseRetrive = course_latest.getClasstitle();
       int CourseID = course_latest.getCourseid();
       int Course2 = course_latest.getCreditHours();
       pk.edu.nust.seecs.gradebook.entity.Teacher teacherget = course_latest.getTeacher();
       
       //list of three students
       
        CourseDao take_course = new CourseDao();
        
     
         
         
         pk.edu.nust.seecs.gradebook.entity.Student s1;
         pk.edu.nust.seecs.gradebook.entity.Student s2;
         pk.edu.nust.seecs.gradebook.entity.Student s3;
         s1 = new pk.edu.nust.seecs.gradebook.entity.Student();
         
         String studentName = s1.getName();
         int studnet2 = s1.hashCode();
         
         if(studnet2!=0){
         good = 1;
         }
       return good;
         
    }
    
    public static int businessLogicAdd(){
        Date d = new Date();
        d.setYear(2016);
        d.setMonth(5);
        
        Date d2 = new Date();
        d2.setYear(2016);
        d2.setMonth(7);
        
        AttendanceSystem attend_system = new AttendanceSystem();
       
        //add the two new courses
        pk.edu.nust.seecs.gradebook.entity.Course course_latest,course_latest_2;
        
       course_latest = new pk.edu.nust.seecs.gradebook.entity.Course("Advanced Programming", d, d2, 4);
       
       course_latest_2 = new pk.edu.nust.seecs.gradebook.entity.Course("Database", d, d2, 4);
        
       pk.edu.nust.seecs.gradebook.entity.Teacher Instructor1,Instructor2;
        
       //add the teachers
       Instructor1 = new  pk.edu.nust.seecs.gradebook.entity.Teacher("Sir Fahad Satti");
       
       Instructor2 = new  pk.edu.nust.seecs.gradebook.entity.Teacher("Sir Khalid Latif");
       
       
       //list of three students
       
        CourseDao take_course = new CourseDao();
        
        take_course.addCourse(null);
         
         
         pk.edu.nust.seecs.gradebook.entity.Student s1,s2,s3;
         s1 = new pk.edu.nust.seecs.gradebook.entity.Student();
         s2 = new pk.edu.nust.seecs.gradebook.entity.Student();
           s3 = new pk.edu.nust.seecs.gradebook.entity.Student();
         
           //set the students
         s1.setName("Daim Ali");
         s2.setName(" Qaim Ali");
         s3.setName("Nizam Ali");
         good = 2;
         
         return good;
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
         
     
        System.out.println("       Welcome, to the apllication       ");  
        System.out.println("       Please, Press 1 to add the new course   ");
        System.out.println("       Please, Press 2 to retrieve the data    ");
         int i = sc.nextInt();
        
         if(i == 1){
       int g =  businessLogicAdd();
         }
         
         if(i == 2){
          int k = businessLogicRetrive();
         }
            
    }   

    
    
}

